//** otakudesu

module.exports = {
CmD: ['search'],
categori: 'otakudesu',
exec: async (m, bob, { prefix, q }) => {
m.reply('cooming soon')
}
}

